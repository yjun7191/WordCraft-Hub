import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { SiteShell } from "@/components/site-shell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { useQuery } from "@tanstack/react-query";
import { Clock, Users2, DollarSign, Calendar, Award } from "lucide-react";
import { useSession, useUserRoles } from "@/lib/auth-hooks";
import { useState } from "react";
import { toast } from "sonner";
import { z } from "zod";

export const Route = createFileRoute("/jobs/$id")({
  head: ({ params }) => ({
    meta: [
      { title: `Job — WordCraft Hub` },
      { name: "description", content: "View job details and apply on WordCraft Hub." },
    ],
  }),
  component: JobDetail,
});

function JobDetail() {
  const { id } = Route.useParams();
  const { user } = useSession();
  const { isFreelancer, isClient } = useUserRoles(user?.id);

  const jobQ = useQuery({
    queryKey: ["job", id],
    queryFn: async () => {
      const { data, error } = await supabase.from("jobs").select("*, categories(name, slug)").eq("id", id).maybeSingle();
      if (error) throw error;
      if (!data) return null;
      const clientProfile = data.client_id
        ? (await supabase.from("profiles").select("full_name, country").eq("id", data.client_id).maybeSingle()).data
        : null;
      return { ...data, client_profile: clientProfile };
    },
  });

  const applicationQ = useQuery({
    queryKey: ["my-application", id, user?.id],
    queryFn: async () => {
      if (!user) return null;
      const { data } = await supabase.from("applications").select("*").eq("job_id", id).eq("freelancer_id", user.id).maybeSingle();
      return data;
    },
    enabled: !!user,
  });

  const j = jobQ.data;
  const isOwner = user && j && user.id === j.client_id;

  return (
    <SiteShell>
      <section className="mx-auto max-w-4xl px-4 py-10 sm:px-6 lg:px-8">
        {jobQ.isLoading && <div className="h-64 animate-pulse rounded-2xl bg-muted/60" />}
        {!jobQ.isLoading && !j && (
          <Card><CardContent className="p-10 text-center text-muted-foreground">Job not found. <Link to="/jobs" className="text-primary underline">Back to jobs</Link></CardContent></Card>
        )}
        {j && (
          <>
            <Link to="/jobs" className="text-sm text-muted-foreground hover:text-foreground">← Back to jobs</Link>
            <div className="mt-4 flex flex-wrap items-start justify-between gap-4">
              <div className="flex-1 min-w-0">
                <div className="flex flex-wrap items-center gap-2">
                  {j.categories && <Badge variant="outline">{j.categories.name}</Badge>}
                  <Badge className="bg-secondary/15 text-secondary-foreground border-secondary/20 capitalize">{j.experience_level}</Badge>
                </div>
                <h1 className="mt-3 font-display text-3xl font-bold">{j.title}</h1>
                <p className="mt-2 text-sm text-muted-foreground">
                  Posted by {j.client_profile?.full_name ?? "Client"} {j.client_profile?.country ? `· ${j.client_profile.country}` : ""} · {new Date(j.created_at).toLocaleDateString()}
                </p>
              </div>
            </div>

            <div className="mt-8 grid gap-6 md:grid-cols-3">
              <Stat icon={DollarSign} label="Budget" value={j.budget_min && j.budget_max ? `$${j.budget_min}–$${j.budget_max}${j.is_hourly ? "/hr" : ""}` : "TBD"} />
              <Stat icon={Users2} label="Applicants" value={String(j.applications_count)} />
              <Stat icon={Calendar} label="Deadline" value={j.deadline ? new Date(j.deadline).toLocaleDateString() : "Flexible"} />
            </div>

            <Card className="mt-6">
              <CardHeader><CardTitle className="font-display">About this job</CardTitle></CardHeader>
              <CardContent className="prose prose-sm max-w-none whitespace-pre-wrap text-foreground/90">{j.description}</CardContent>
            </Card>

            {(j.skills?.length || j.languages?.length) ? (
              <Card className="mt-6">
                <CardHeader><CardTitle className="font-display">Requirements</CardTitle></CardHeader>
                <CardContent className="space-y-4">
                  {j.skills?.length ? (
                    <div>
                      <div className="text-xs uppercase tracking-wide text-muted-foreground mb-2">Skills</div>
                      <div className="flex flex-wrap gap-2">{j.skills.map((s: string) => <Badge key={s} variant="secondary" className="bg-muted">{s}</Badge>)}</div>
                    </div>
                  ) : null}
                  {j.languages?.length ? (
                    <div>
                      <div className="text-xs uppercase tracking-wide text-muted-foreground mb-2">Languages</div>
                      <div className="flex flex-wrap gap-2">{j.languages.map((s: string) => <Badge key={s} variant="outline">{s}</Badge>)}</div>
                    </div>
                  ) : null}
                </CardContent>
              </Card>
            ) : null}

            <div className="mt-8">
              {!user && (
                <Button asChild size="lg" className="bg-gradient-brand"><Link to="/auth">Sign in to apply</Link></Button>
              )}
              {user && isOwner && (
                <Card className="bg-surface"><CardContent className="p-6 text-sm">You posted this job. Manage applicants from your <Link to="/dashboard" className="text-primary underline">dashboard</Link>.</CardContent></Card>
              )}
              {user && !isOwner && !isFreelancer && (
                <Card><CardContent className="p-6 text-sm">
                  Only freelancer accounts can apply. <Link to="/onboarding" className="text-primary underline">Add a freelancer profile</Link> to apply for jobs.
                </CardContent></Card>
              )}
              {user && !isOwner && isFreelancer && applicationQ.data && (
                <Card className="border-secondary/40 bg-secondary/5"><CardContent className="p-6 text-sm">
                  <div className="flex items-center gap-2 font-medium"><Award className="h-4 w-4 text-secondary" /> You already applied on {new Date(applicationQ.data.created_at).toLocaleDateString()}</div>
                  <div className="mt-1 text-muted-foreground capitalize">Status: {applicationQ.data.status}</div>
                </CardContent></Card>
              )}
              {user && !isOwner && isFreelancer && !applicationQ.data && (
                <ApplyForm jobId={j.id} onApplied={() => applicationQ.refetch()} />
              )}
            </div>
          </>
        )}
      </section>
    </SiteShell>
  );
}

function Stat({ icon: Icon, label, value }: { icon: React.ComponentType<{ className?: string }>; label: string; value: string }) {
  return (
    <div className="rounded-2xl border border-border bg-card p-4">
      <div className="flex items-center gap-2 text-xs text-muted-foreground"><Icon className="h-4 w-4" />{label}</div>
      <div className="mt-1 font-display text-lg font-semibold">{value}</div>
    </div>
  );
}

const applySchema = z.object({
  cover_letter: z.string().trim().min(50, "At least 50 characters").max(3000),
  proposed_amount: z.number().positive().max(999999).optional(),
  estimated_days: z.number().int().positive().max(365).optional(),
});

function ApplyForm({ jobId, onApplied }: { jobId: string; onApplied: () => void }) {
  const { user } = useSession();
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({ cover_letter: "", proposed_amount: "", estimated_days: "" });

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    const parsed = applySchema.safeParse({
      cover_letter: form.cover_letter,
      proposed_amount: form.proposed_amount ? Number(form.proposed_amount) : undefined,
      estimated_days: form.estimated_days ? Number(form.estimated_days) : undefined,
    });
    if (!parsed.success) return toast.error(parsed.error.issues[0].message);
    if (!user) return;
    setLoading(true);
    const { error } = await supabase.from("applications").insert({
      job_id: jobId,
      freelancer_id: user.id,
      cover_letter: parsed.data.cover_letter,
      proposed_amount: parsed.data.proposed_amount ?? null,
      estimated_days: parsed.data.estimated_days ?? null,
    });
    setLoading(false);
    if (error) return toast.error(error.message);
    toast.success("Proposal submitted!");
    onApplied();
  }

  return (
    <Card>
      <CardHeader><CardTitle className="font-display">Submit a proposal</CardTitle></CardHeader>
      <CardContent>
        <form onSubmit={submit} className="space-y-4">
          <div>
            <Label htmlFor="cover">Cover letter</Label>
            <Textarea id="cover" rows={6} placeholder="Introduce yourself and explain why you're a great fit…" value={form.cover_letter} onChange={(e) => setForm({ ...form, cover_letter: e.target.value })} maxLength={3000} />
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <Label htmlFor="amount">Your bid (USD)</Label>
              <Input id="amount" type="number" min="1" step="0.01" placeholder="e.g. 500" value={form.proposed_amount} onChange={(e) => setForm({ ...form, proposed_amount: e.target.value })} />
            </div>
            <div>
              <Label htmlFor="days">Delivery time (days)</Label>
              <Input id="days" type="number" min="1" placeholder="e.g. 7" value={form.estimated_days} onChange={(e) => setForm({ ...form, estimated_days: e.target.value })} />
            </div>
          </div>
          <Button type="submit" disabled={loading} className="bg-gradient-brand hover:opacity-90">
            {loading ? "Submitting…" : "Submit proposal"}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
