import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteShell } from "@/components/site-shell";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { UserPlus, Search, MessageCircle, ShieldCheck } from "lucide-react";

export const Route = createFileRoute("/how-it-works")({
  head: () => ({
    meta: [
      { title: "How it works — WordCraft Hub" },
      { name: "description", content: "See how WordCraft Hub connects clients with vetted freelancers for language services — in four simple steps." },
      { property: "og:title", content: "How WordCraft Hub works" },
      { property: "og:description", content: "See how WordCraft Hub connects clients with vetted freelancers in four simple steps." },
    ],
  }),
  component: HowItWorks,
});

function HowItWorks() {
  return (
    <SiteShell>
      <section className="mx-auto max-w-4xl px-4 py-20 sm:px-6 lg:px-8">
        <Badge variant="outline">How it works</Badge>
        <h1 className="mt-3 font-display text-4xl font-bold sm:text-5xl">From brief to delivery, in four steps.</h1>
        <p className="mt-4 text-lg text-muted-foreground">Whether you're hiring or applying, WordCraft Hub keeps the process transparent and fair.</p>

        <div className="mt-16 space-y-8">
          {[
            { i: "01", t: "Create your account", d: "Sign up as a client or freelancer with email or Google. Complete your profile to stand out.", icon: UserPlus },
            { i: "02", t: "Post or discover work", d: "Clients post detailed briefs. Freelancers search jobs by category, language, and budget.", icon: Search },
            { i: "03", t: "Chat and hire", d: "Review proposals, message shortlisted freelancers, and hire the right fit for your project.", icon: MessageCircle },
            { i: "04", t: "Deliver and rate", d: "Track progress, exchange deliverables, and rate the experience when you're done.", icon: ShieldCheck },
          ].map((s, i) => (
            <div key={s.i} className="grid gap-6 rounded-3xl border border-border bg-card p-8 md:grid-cols-[auto_1fr] md:items-center">
              <div className="grid h-14 w-14 place-items-center rounded-2xl bg-gradient-brand shadow-glow">
                <s.icon className="h-6 w-6 text-primary-foreground" />
              </div>
              <div>
                <div className="text-xs font-mono text-accent">STEP {s.i}</div>
                <h3 className="mt-1 font-display text-xl font-semibold">{s.t}</h3>
                <p className="mt-1 text-muted-foreground">{s.d}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-16 rounded-3xl bg-gradient-hero p-10 text-center shadow-elegant">
          <h2 className="font-display text-2xl font-bold text-primary-foreground">Ready to get started?</h2>
          <div className="mt-6 flex flex-wrap justify-center gap-3">
            <Button asChild size="lg" className="bg-accent text-accent-foreground hover:bg-accent/90"><Link to="/auth">Create free account</Link></Button>
            <Button asChild size="lg" variant="outline" className="bg-transparent text-primary-foreground border-primary-foreground/40 hover:bg-primary-foreground/10"><Link to="/jobs">Browse jobs</Link></Button>
          </div>
        </div>
      </section>
    </SiteShell>
  );
}
