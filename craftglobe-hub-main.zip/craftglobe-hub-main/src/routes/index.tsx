import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteShell } from "@/components/site-shell";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { supabase } from "@/integrations/supabase/client";
import { useQuery } from "@tanstack/react-query";
import { ArrowRight, Search, ShieldCheck, Sparkles, Globe2, Zap, Users, Star, Mic, Languages, Captions, ScanText, PenLine, FileText, GraduationCap, Headset } from "lucide-react";
import heroImg from "@/assets/hero-wordcraft.jpg";
import { useState } from "react";
import { useNavigate } from "@tanstack/react-router";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "WordCraft Hub — Marketplace for Language Professionals" },
      { name: "description", content: "Hire vetted freelancers for transcription, translation, subtitling, proofreading, editing, and content writing. Connecting words, creating opportunities." },
    ],
  }),
  component: Home,
});

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  Mic, Languages, Captions, ScanText, PenLine, FileText, GraduationCap, Headset, Sparkles,
};

function Home() {
  const navigate = useNavigate();
  const [q, setQ] = useState("");

  const categoriesQ = useQuery({
    queryKey: ["home-categories"],
    queryFn: async () => {
      const { data, error } = await supabase.from("categories").select("*").order("sort_order").limit(9);
      if (error) throw error;
      return data;
    },
  });

  const jobsQ = useQuery({
    queryKey: ["home-jobs"],
    queryFn: async () => {
      const { data, error } = await supabase.from("jobs").select("id, title, budget_min, budget_max, is_hourly, experience_level, created_at, applications_count, category_id").eq("status", "open").order("created_at", { ascending: false }).limit(6);
      if (error) throw error;
      return data;
    },
  });

  return (
    <SiteShell>
      {/* HERO */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-radial pointer-events-none" />
        <div className="mx-auto grid max-w-7xl gap-10 px-4 py-16 sm:px-6 lg:grid-cols-2 lg:gap-16 lg:py-24 lg:px-8">
          <div className="flex flex-col justify-center">
            <Badge variant="secondary" className="w-fit gap-1.5 bg-secondary/15 text-secondary-foreground border-secondary/20">
              <Sparkles className="h-3 w-3" /> New — AI-powered matching
            </Badge>
            <h1 className="mt-6 font-display text-4xl font-bold leading-[1.1] tracking-tight sm:text-5xl lg:text-6xl">
              Connecting words, <br />
              <span className="text-gradient">creating opportunities.</span>
            </h1>
            <p className="mt-6 max-w-lg text-lg text-muted-foreground">
              Your global marketplace for translators, transcriptionists, subtitlers, editors, and content writers. Vetted talent, fair pricing, real deadlines.
            </p>

            <form
              onSubmit={(e) => { e.preventDefault(); navigate({ to: "/jobs", search: { q } as never }); }}
              className="mt-8 flex max-w-lg items-center gap-2 rounded-2xl border border-border bg-card p-2 shadow-soft"
            >
              <Search className="ml-2 h-5 w-5 text-muted-foreground" />
              <Input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Try 'medical transcription' or 'Spanish translator'"
                className="border-0 bg-transparent shadow-none focus-visible:ring-0"
              />
              <Button type="submit" className="bg-gradient-brand hover:opacity-90">Search</Button>
            </form>

            <div className="mt-6 flex flex-wrap items-center gap-x-6 gap-y-2 text-sm text-muted-foreground">
              <span className="flex items-center gap-1.5"><ShieldCheck className="h-4 w-4 text-secondary" /> Vetted freelancers</span>
              <span className="flex items-center gap-1.5"><Globe2 className="h-4 w-4 text-secondary" /> 40+ languages</span>
              <span className="flex items-center gap-1.5"><Zap className="h-4 w-4 text-accent" /> Fast turnaround</span>
            </div>
          </div>

          <div className="relative">
            <div className="relative rounded-3xl overflow-hidden shadow-elegant ring-1 ring-border">
              <img src={heroImg} alt="Layered gradient artwork evoking global language services" width={1600} height={1200} className="h-full w-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-tr from-primary/40 via-transparent to-transparent" />
            </div>
            <div className="absolute -bottom-6 -left-6 hidden md:block glass rounded-2xl p-4 shadow-soft">
              <div className="flex items-center gap-3">
                <div className="grid h-10 w-10 place-items-center rounded-full bg-secondary/20"><Star className="h-5 w-5 text-secondary" /></div>
                <div>
                  <div className="text-xs text-muted-foreground">Average rating</div>
                  <div className="font-display text-lg font-bold">4.9 / 5</div>
                </div>
              </div>
            </div>
            <div className="absolute -top-6 -right-6 hidden md:block glass rounded-2xl p-4 shadow-soft">
              <div className="text-xs text-muted-foreground">Active projects</div>
              <div className="font-display text-lg font-bold">2,384</div>
            </div>
          </div>
        </div>
      </section>

      {/* STATS */}
      <section className="border-y border-border/60 bg-surface">
        <div className="mx-auto grid max-w-7xl grid-cols-2 gap-6 px-4 py-10 sm:grid-cols-4 sm:px-6 lg:px-8">
          {[
            { k: "12K+", l: "Verified freelancers" },
            { k: "40+", l: "Languages covered" },
            { k: "98%", l: "On-time delivery" },
            { k: "4.9★", l: "Average rating" },
          ].map((s) => (
            <div key={s.l} className="text-center">
              <div className="font-display text-3xl font-bold text-gradient">{s.k}</div>
              <div className="mt-1 text-xs text-muted-foreground">{s.l}</div>
            </div>
          ))}
        </div>
      </section>

      {/* CATEGORIES */}
      <section className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8">
        <div className="flex flex-col items-start justify-between gap-4 md:flex-row md:items-end">
          <div>
            <Badge variant="outline" className="mb-3">Explore</Badge>
            <h2 className="font-display text-3xl font-bold sm:text-4xl">Browse by category</h2>
            <p className="mt-2 max-w-xl text-muted-foreground">Hire specialists in transcription, translation, editing, and more — matched to your industry.</p>
          </div>
          <Button asChild variant="ghost" className="group"><Link to="/categories">All categories <ArrowRight className="ml-1 h-4 w-4 transition group-hover:translate-x-0.5" /></Link></Button>
        </div>
        <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {(categoriesQ.data ?? []).map((c) => {
            const Icon = iconMap[c.icon ?? "Sparkles"] ?? Sparkles;
            return (
              <Link key={c.id} to="/jobs" search={{ category: c.slug } as never}
                className="group relative overflow-hidden rounded-2xl border border-border bg-card p-6 transition hover:shadow-elegant hover:-translate-y-0.5">
                <div className="absolute inset-0 bg-gradient-brand opacity-0 transition group-hover:opacity-[0.04]" />
                <div className="relative flex items-start gap-4">
                  <div className="grid h-12 w-12 place-items-center rounded-xl bg-gradient-brand shadow-glow">
                    <Icon className="h-6 w-6 text-primary-foreground" />
                  </div>
                  <div>
                    <h3 className="font-display font-semibold">{c.name}</h3>
                    <p className="mt-1 text-sm text-muted-foreground line-clamp-2">{c.description}</p>
                  </div>
                </div>
              </Link>
            );
          })}
        </div>
      </section>

      {/* FEATURED JOBS */}
      <section className="bg-surface">
        <div className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8">
          <div className="flex items-end justify-between gap-4">
            <div>
              <Badge variant="outline" className="mb-3">Fresh listings</Badge>
              <h2 className="font-display text-3xl font-bold sm:text-4xl">Recent opportunities</h2>
            </div>
            <Button asChild variant="ghost"><Link to="/jobs">View all <ArrowRight className="ml-1 h-4 w-4" /></Link></Button>
          </div>
          <div className="mt-10 grid gap-4 md:grid-cols-2">
            {jobsQ.isLoading && Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="h-40 animate-pulse rounded-2xl bg-muted/60" />
            ))}
            {jobsQ.data?.length === 0 && (
              <Card className="md:col-span-2"><CardContent className="p-8 text-center text-muted-foreground">No jobs posted yet. Be the first — <Link to="/auth" className="text-primary underline">sign up</Link> to post one.</CardContent></Card>
            )}
            {jobsQ.data?.map((j) => (
              <Link key={j.id} to="/jobs/$id" params={{ id: j.id }} className="group rounded-2xl border border-border bg-card p-6 transition hover:shadow-elegant hover:-translate-y-0.5">
                <div className="flex items-start justify-between gap-4">
                  <h3 className="font-display font-semibold group-hover:text-primary transition-colors line-clamp-2">{j.title}</h3>
                  <Badge variant="secondary" className="shrink-0 bg-secondary/15 text-secondary-foreground border-secondary/20 capitalize">{j.experience_level}</Badge>
                </div>
                <div className="mt-4 flex flex-wrap items-center gap-x-4 gap-y-2 text-sm">
                  <span className="font-semibold text-foreground">
                    {j.budget_min && j.budget_max ? `$${j.budget_min}–$${j.budget_max}` : "Budget: TBD"}
                    {j.is_hourly ? " / hr" : ""}
                  </span>
                  <span className="text-muted-foreground">{j.applications_count} applicants</span>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* HOW IT WORKS */}
      <section className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8">
        <div className="text-center">
          <Badge variant="outline" className="mb-3">Simple</Badge>
          <h2 className="font-display text-3xl font-bold sm:text-4xl">How WordCraft Hub works</h2>
        </div>
        <div className="mt-14 grid gap-8 md:grid-cols-3">
          {[
            { i: "01", t: "Post or apply", d: "Clients post detailed briefs. Freelancers apply with tailored proposals.", icon: FileText },
            { i: "02", t: "Match & chat", d: "Review verified profiles, portfolios, and reviews. Chat before hiring.", icon: Users },
            { i: "03", t: "Deliver & pay", d: "Track milestones and release payment on completion. Rate the experience.", icon: ShieldCheck },
          ].map((step) => (
            <div key={step.i} className="relative rounded-3xl border border-border bg-card p-8">
              <div className="text-sm font-mono text-accent">{step.i}</div>
              <div className="mt-4 grid h-12 w-12 place-items-center rounded-xl bg-gradient-brand shadow-glow">
                <step.icon className="h-6 w-6 text-primary-foreground" />
              </div>
              <h3 className="mt-4 font-display text-lg font-semibold">{step.t}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{step.d}</p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="mx-auto max-w-7xl px-4 pb-24 sm:px-6 lg:px-8">
        <div className="relative overflow-hidden rounded-3xl bg-gradient-hero p-10 shadow-elegant md:p-16">
          <div className="absolute inset-0 bg-gradient-radial opacity-40" />
          <div className="relative grid gap-8 md:grid-cols-2 md:items-center">
            <div>
              <h2 className="font-display text-3xl font-bold text-primary-foreground sm:text-4xl">Ready to craft with words?</h2>
              <p className="mt-3 max-w-md text-primary-foreground/80">Join thousands of language professionals building meaningful careers on WordCraft Hub.</p>
            </div>
            <div className="flex flex-wrap gap-3 md:justify-end">
              <Button asChild size="lg" className="bg-accent text-accent-foreground hover:bg-accent/90"><Link to="/auth">Get started free</Link></Button>
              <Button asChild size="lg" variant="outline" className="bg-transparent text-primary-foreground border-primary-foreground/40 hover:bg-primary-foreground/10"><Link to="/jobs">Browse jobs</Link></Button>
            </div>
          </div>
        </div>
      </section>
    </SiteShell>
  );
}
