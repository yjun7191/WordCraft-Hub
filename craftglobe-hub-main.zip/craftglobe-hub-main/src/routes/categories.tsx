import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteShell } from "@/components/site-shell";
import { supabase } from "@/integrations/supabase/client";
import { useQuery } from "@tanstack/react-query";
import { Mic, Languages, Captions, ScanText, PenLine, FileText, GraduationCap, Headset, Sparkles } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export const Route = createFileRoute("/categories")({
  head: () => ({
    meta: [
      { title: "Categories — WordCraft Hub" },
      { name: "description", content: "Explore language service categories: transcription, translation, subtitling, editing, writing, and more." },
      { property: "og:title", content: "Categories — WordCraft Hub" },
      { property: "og:description", content: "Explore language service categories: transcription, translation, subtitling, editing, writing, and more." },
    ],
  }),
  component: CategoriesPage,
});

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = { Mic, Languages, Captions, ScanText, PenLine, FileText, GraduationCap, Headset, Sparkles };

function CategoriesPage() {
  const q = useQuery({
    queryKey: ["categories-all-page"],
    queryFn: async () => {
      const { data, error } = await supabase.from("categories").select("*").order("sort_order");
      if (error) throw error;
      return data;
    },
  });

  const jobsQ = useQuery({
    queryKey: ["categories-active-jobs"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("jobs")
        .select("category_id, budget_min, budget_max, is_hourly, status")
        .eq("status", "open");
      if (error) throw error;
      return data ?? [];
    },
  });

  const statsByCategory = (() => {
    const map = new Map<string, { count: number; min: number | null; max: number | null }>();
    for (const j of jobsQ.data ?? []) {
      if (!j.is_hourly || !j.category_id) continue;
      const cur = map.get(j.category_id) ?? { count: 0, min: null as number | null, max: null as number | null };
      cur.count += 1;
      if (j.budget_min != null) cur.min = cur.min == null ? j.budget_min : Math.min(cur.min, j.budget_min);
      if (j.budget_max != null) cur.max = cur.max == null ? j.budget_max : Math.max(cur.max, j.budget_max);
      map.set(j.category_id, cur);
    }
    return map;
  })();

  return (
    <SiteShell>
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <Badge variant="outline">All categories</Badge>
        <h1 className="mt-3 font-display text-4xl font-bold">The full catalog of language services</h1>
        <p className="mt-3 max-w-2xl text-muted-foreground">Every category on WordCraft Hub is staffed by vetted specialists. Click through to browse open jobs.</p>

        <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {q.data?.map((c) => {
            const Icon = iconMap[c.icon ?? "Sparkles"] ?? Sparkles;
            const stats = statsByCategory.get(c.id);
            const rate = stats && (stats.min != null || stats.max != null)
              ? stats.min != null && stats.max != null && stats.min !== stats.max
                ? `$${stats.min}–$${stats.max}/hr`
                : `$${stats.min ?? stats.max}/hr`
              : null;
            return (
              <Link key={c.id} to="/jobs" search={{ category: c.slug } as never}
                className="group rounded-2xl border border-border bg-card p-6 transition hover:shadow-elegant hover:-translate-y-0.5">
                <div className="grid h-12 w-12 place-items-center rounded-xl bg-gradient-brand shadow-glow"><Icon className="h-6 w-6 text-primary-foreground" /></div>
                <h3 className="mt-4 font-display font-semibold">{c.name}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{c.description}</p>
                <div className="mt-4 flex flex-wrap items-center gap-2">
                  <Badge variant="secondary" className="bg-secondary/15 text-secondary-foreground border-secondary/20">
                    {stats?.count ?? 0} active {stats?.count === 1 ? "job" : "jobs"}
                  </Badge>
                  {rate && (
                    <Badge variant="outline" className="border-accent/40 text-accent-foreground">
                      {rate}
                    </Badge>
                  )}
                </div>
              </Link>
            );
          })}
        </div>
      </section>
    </SiteShell>
  );
}

