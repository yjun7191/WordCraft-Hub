import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteShell } from "@/components/site-shell";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Search, MapPin, Clock, Users2 } from "lucide-react";
import { z } from "zod";

const searchSchema = z.object({
  q: z.string().optional(),
  category: z.string().optional(),
  level: z.enum(["entry", "intermediate", "expert"]).optional(),
});

export const Route = createFileRoute("/jobs")({
  validateSearch: searchSchema,
  head: () => ({
    meta: [
      { title: "Browse language jobs — WordCraft Hub" },
      { name: "description", content: "Find translation, transcription, subtitling, editing, and content writing jobs from clients worldwide." },
      { property: "og:title", content: "Browse language jobs — WordCraft Hub" },
      { property: "og:description", content: "Find translation, transcription, subtitling, editing, and content writing jobs from clients worldwide." },
    ],
  }),
  component: JobsPage,
});

function JobsPage() {
  const search = Route.useSearch();
  const navigate = Route.useNavigate();
  const [q, setQ] = useState(search.q ?? "");

  const categoriesQ = useQuery({
    queryKey: ["categories-all"],
    queryFn: async () => {
      const { data, error } = await supabase.from("categories").select("id, name, slug").order("sort_order");
      if (error) throw error;
      return data;
    },
  });

  const jobsQ = useQuery({
    queryKey: ["jobs-list", search],
    queryFn: async () => {
      let query = supabase
        .from("jobs")
        .select("id, title, description, budget_min, budget_max, is_hourly, experience_level, deadline, created_at, applications_count, category_id, skills, languages")
        .eq("status", "open")
        .order("created_at", { ascending: false })
        .limit(50);

      if (search.q) query = query.ilike("title", `%${search.q}%`);
      if (search.level) query = query.eq("experience_level", search.level);
      if (search.category) {
        const cat = categoriesQ.data?.find((c) => c.slug === search.category);
        if (cat) query = query.eq("category_id", cat.id);
      }
      const { data, error } = await query;
      if (error) throw error;
      return data;
    },
    enabled: !categoriesQ.isLoading,
  });

  return (
    <SiteShell>
      <section className="border-b border-border/60 bg-surface">
        <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
          <Badge variant="outline">Marketplace</Badge>
          <h1 className="mt-3 font-display text-3xl font-bold sm:text-4xl">Find your next project</h1>
          <p className="mt-2 max-w-xl text-muted-foreground">Browse open jobs from clients around the world.</p>

          <form onSubmit={(e) => { e.preventDefault(); navigate({ search: (s: typeof search) => ({ ...s, q }) }); }}
            className="mt-6 flex flex-col gap-2 rounded-2xl border border-border bg-card p-2 shadow-soft sm:flex-row">
            <div className="flex flex-1 items-center gap-2 px-2">
              <Search className="h-5 w-5 text-muted-foreground" />
              <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search jobs by title or keyword" className="border-0 bg-transparent focus-visible:ring-0 shadow-none" />
            </div>
            <Select value={search.category ?? "all"} onValueChange={(v) => navigate({ search: (s: typeof search) => ({ ...s, category: v === "all" ? undefined : v }) })}>
              <SelectTrigger className="sm:w-48"><SelectValue placeholder="Category" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All categories</SelectItem>
                {categoriesQ.data?.map((c) => <SelectItem key={c.id} value={c.slug}>{c.name}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={search.level ?? "any"} onValueChange={(v) => navigate({ search: (s: typeof search) => ({ ...s, level: v === "any" ? undefined : (v as "entry" | "intermediate" | "expert") }) })}>
              <SelectTrigger className="sm:w-40"><SelectValue placeholder="Level" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="any">Any level</SelectItem>
                <SelectItem value="entry">Entry</SelectItem>
                <SelectItem value="intermediate">Intermediate</SelectItem>
                <SelectItem value="expert">Expert</SelectItem>
              </SelectContent>
            </Select>
            <Button type="submit" className="bg-gradient-brand hover:opacity-90">Search</Button>
          </form>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
        <p className="text-sm text-muted-foreground mb-6">
          {jobsQ.isLoading ? "Loading…" : `${jobsQ.data?.length ?? 0} job${(jobsQ.data?.length ?? 0) === 1 ? "" : "s"} found`}
        </p>

        <div className="space-y-4">
          {jobsQ.isLoading && Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="h-32 animate-pulse rounded-2xl bg-muted/60" />
          ))}
          {jobsQ.data?.length === 0 && (
            <Card><CardContent className="p-10 text-center text-muted-foreground">No jobs match your filters yet. Try broadening your search.</CardContent></Card>
          )}
          {jobsQ.data?.map((j) => (
            <Link key={j.id} to="/jobs/$id" params={{ id: j.id }} className="block">
              <Card className="transition hover:shadow-elegant hover:-translate-y-0.5">
                <CardContent className="p-6">
                  <div className="flex flex-wrap items-start justify-between gap-4">
                    <div className="flex-1 min-w-0">
                      <h3 className="font-display text-lg font-semibold hover:text-primary transition-colors">{j.title}</h3>
                      <p className="mt-2 text-sm text-muted-foreground line-clamp-2">{j.description}</p>
                      <div className="mt-4 flex flex-wrap gap-2">
                        {(j.skills ?? []).slice(0, 5).map((s) => (
                          <Badge key={s} variant="secondary" className="bg-muted text-foreground/80 font-normal">{s}</Badge>
                        ))}
                      </div>
                    </div>
                    <div className="shrink-0 text-right">
                      <div className="font-display text-lg font-bold">
                        {j.budget_min && j.budget_max ? `$${j.budget_min}–$${j.budget_max}` : "Budget: TBD"}
                      </div>
                      <div className="text-xs text-muted-foreground">{j.is_hourly ? "hourly rate" : "fixed price"}</div>
                    </div>
                  </div>
                  <div className="mt-4 flex flex-wrap items-center gap-x-4 gap-y-2 text-xs text-muted-foreground border-t border-border/60 pt-3">
                    <span className="flex items-center gap-1 capitalize"><MapPin className="h-3.5 w-3.5" />{j.experience_level}</span>
                    <span className="flex items-center gap-1"><Users2 className="h-3.5 w-3.5" />{j.applications_count} applicants</span>
                    <span className="flex items-center gap-1"><Clock className="h-3.5 w-3.5" />{new Date(j.created_at).toLocaleDateString()}</span>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </section>
    </SiteShell>
  );
}
