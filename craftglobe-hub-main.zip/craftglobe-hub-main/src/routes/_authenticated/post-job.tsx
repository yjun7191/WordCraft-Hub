import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { SiteShell } from "@/components/site-shell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { useSession, useUserRoles } from "@/lib/auth-hooks";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { z } from "zod";

export const Route = createFileRoute("/_authenticated/post-job")({
  head: () => ({ meta: [{ title: "Post a job — WordCraft Hub" }, { name: "robots", content: "noindex" }] }),
  component: PostJob,
});

const schema = z.object({
  title: z.string().trim().min(10, "Title must be at least 10 characters").max(140),
  description: z.string().trim().min(50, "Describe the work in at least 50 characters").max(5000),
  category_id: z.string().uuid("Pick a category"),
  budget_min: z.number().positive().max(1_000_000).optional(),
  budget_max: z.number().positive().max(1_000_000).optional(),
  experience_level: z.enum(["entry", "intermediate", "expert"]),
  is_hourly: z.boolean(),
  deadline: z.string().optional(),
  skills: z.string().max(500).optional(),
  languages: z.string().max(300).optional(),
});

function PostJob() {
  const { user } = useSession();
  const { isClient, loading: rolesLoading } = useUserRoles(user?.id);
  const navigate = useNavigate();
  const [saving, setSaving] = useState(false);

  const catsQ = useQuery({
    queryKey: ["categories-post"],
    queryFn: async () => {
      const { data, error } = await supabase.from("categories").select("id, name").order("sort_order");
      if (error) throw error;
      return data;
    },
  });

  const [form, setForm] = useState({
    title: "", description: "", category_id: "", budget_min: "", budget_max: "",
    experience_level: "intermediate" as "entry" | "intermediate" | "expert",
    is_hourly: "false", deadline: "", skills: "", languages: "",
  });

  if (!rolesLoading && !isClient) {
    return (
      <SiteShell>
        <section className="mx-auto max-w-2xl px-4 py-16 sm:px-6 lg:px-8 text-center">
          <h1 className="font-display text-2xl font-bold">You need a client account to post jobs</h1>
          <p className="mt-2 text-muted-foreground">Every account starts as a client — hold on while we set that up.</p>
          <Button asChild className="mt-6"><Link to="/onboarding">Set up your account</Link></Button>
        </section>
      </SiteShell>
    );
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    const parsed = schema.safeParse({
      title: form.title,
      description: form.description,
      category_id: form.category_id,
      budget_min: form.budget_min ? Number(form.budget_min) : undefined,
      budget_max: form.budget_max ? Number(form.budget_max) : undefined,
      experience_level: form.experience_level,
      is_hourly: form.is_hourly === "true",
      deadline: form.deadline || undefined,
      skills: form.skills,
      languages: form.languages,
    });
    if (!parsed.success) return toast.error(parsed.error.issues[0].message);
    if (parsed.data.budget_min && parsed.data.budget_max && parsed.data.budget_min > parsed.data.budget_max) {
      return toast.error("Minimum budget can't exceed maximum");
    }
    if (!user) return;
    setSaving(true);
    const { data, error } = await supabase.from("jobs").insert({
      client_id: user.id,
      title: parsed.data.title,
      description: parsed.data.description,
      category_id: parsed.data.category_id,
      budget_min: parsed.data.budget_min ?? null,
      budget_max: parsed.data.budget_max ?? null,
      experience_level: parsed.data.experience_level,
      is_hourly: parsed.data.is_hourly,
      deadline: parsed.data.deadline || null,
      skills: form.skills ? form.skills.split(",").map((s) => s.trim()).filter(Boolean) : [],
      languages: form.languages ? form.languages.split(",").map((s) => s.trim()).filter(Boolean) : [],
    }).select("id").single();
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success("Job posted!");
    navigate({ to: "/jobs/$id", params: { id: data.id } });
  }

  return (
    <SiteShell>
      <section className="mx-auto max-w-2xl px-4 py-10 sm:px-6 lg:px-8">
        <h1 className="font-display text-3xl font-bold">Post a job</h1>
        <p className="mt-1 text-muted-foreground">Attract the right proposals with a clear brief.</p>

        <Card className="mt-8">
          <CardHeader><CardTitle className="font-display">Job details</CardTitle></CardHeader>
          <CardContent>
            <form onSubmit={submit} className="space-y-4">
              <div>
                <Label htmlFor="title">Title</Label>
                <Input id="title" placeholder="e.g. Translate a 20-page medical report EN → FR" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} maxLength={140} required />
              </div>
              <div>
                <Label htmlFor="category">Category</Label>
                <Select value={form.category_id} onValueChange={(v) => setForm({ ...form, category_id: v })}>
                  <SelectTrigger id="category"><SelectValue placeholder="Choose a category" /></SelectTrigger>
                  <SelectContent>{catsQ.data?.map((c) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="desc">Description</Label>
                <Textarea id="desc" rows={7} placeholder="Describe the scope, format, deliverables, and any references…" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} maxLength={5000} required />
              </div>
              <div className="grid gap-4 sm:grid-cols-3">
                <div>
                  <Label htmlFor="level">Experience</Label>
                  <Select value={form.experience_level} onValueChange={(v) => setForm({ ...form, experience_level: v as "entry" | "intermediate" | "expert" })}>
                    <SelectTrigger id="level"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="entry">Entry</SelectItem>
                      <SelectItem value="intermediate">Intermediate</SelectItem>
                      <SelectItem value="expert">Expert</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="type">Pricing</Label>
                  <Select value={form.is_hourly} onValueChange={(v) => setForm({ ...form, is_hourly: v })}>
                    <SelectTrigger id="type"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="false">Fixed price</SelectItem>
                      <SelectItem value="true">Hourly</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="deadline">Deadline</Label>
                  <Input id="deadline" type="date" value={form.deadline} onChange={(e) => setForm({ ...form, deadline: e.target.value })} />
                </div>
              </div>
              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <Label htmlFor="min">Budget min (USD)</Label>
                  <Input id="min" type="number" min="1" step="0.01" value={form.budget_min} onChange={(e) => setForm({ ...form, budget_min: e.target.value })} />
                </div>
                <div>
                  <Label htmlFor="max">Budget max (USD)</Label>
                  <Input id="max" type="number" min="1" step="0.01" value={form.budget_max} onChange={(e) => setForm({ ...form, budget_max: e.target.value })} />
                </div>
              </div>
              <div>
                <Label htmlFor="skills">Skills (comma separated)</Label>
                <Input id="skills" placeholder="Medical, Trados, EN, FR" value={form.skills} onChange={(e) => setForm({ ...form, skills: e.target.value })} />
              </div>
              <div>
                <Label htmlFor="langs">Languages (comma separated)</Label>
                <Input id="langs" placeholder="English, French" value={form.languages} onChange={(e) => setForm({ ...form, languages: e.target.value })} />
              </div>
              <Button type="submit" disabled={saving} className="w-full bg-gradient-brand hover:opacity-90">
                {saving ? "Posting…" : "Post job"}
              </Button>
            </form>
          </CardContent>
        </Card>
      </section>
    </SiteShell>
  );
}
