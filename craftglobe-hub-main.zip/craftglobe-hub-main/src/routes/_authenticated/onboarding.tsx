import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { SiteShell } from "@/components/site-shell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { useSession, useUserRoles } from "@/lib/auth-hooks";
import { Pencil, Users, Sparkles } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/onboarding")({
  head: () => ({ meta: [{ title: "Get started — WordCraft Hub" }, { name: "robots", content: "noindex" }] }),
  component: Onboarding,
});

function Onboarding() {
  const { user } = useSession();
  const { isFreelancer, isClient } = useUserRoles(user?.id);
  const navigate = useNavigate();

  async function pick(role: "client" | "freelancer") {
    const { error } = await supabase.rpc("add_role_to_current_user", { _role: role });
    if (error) return toast.error(error.message);
    toast.success(role === "freelancer" ? "Freelancer role added" : "Client role confirmed");
    navigate({ to: role === "freelancer" ? "/profile" : "/post-job" });
  }

  return (
    <SiteShell>
      <section className="mx-auto max-w-3xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="mx-auto grid h-12 w-12 place-items-center rounded-xl bg-gradient-brand shadow-glow">
          <Sparkles className="h-6 w-6 text-primary-foreground" />
        </div>
        <h1 className="mt-6 text-center font-display text-3xl font-bold sm:text-4xl">How will you use WordCraft Hub?</h1>
        <p className="mt-2 text-center text-muted-foreground">You can switch or use both. Pick one to continue.</p>

        <div className="mt-10 grid gap-6 md:grid-cols-2">
          <button onClick={() => pick("client")} className="group text-left rounded-3xl border border-border bg-card p-8 transition hover:shadow-elegant hover:-translate-y-0.5">
            <div className="grid h-12 w-12 place-items-center rounded-xl bg-gradient-brand shadow-glow">
              <Users className="h-6 w-6 text-primary-foreground" />
            </div>
            <h2 className="mt-4 font-display text-xl font-semibold">I want to hire</h2>
            <p className="mt-2 text-sm text-muted-foreground">Post jobs and hire vetted freelancers for transcription, translation, editing, and more.</p>
            {isClient && <span className="mt-4 inline-block text-xs text-secondary">✓ You already have this role</span>}
          </button>
          <button onClick={() => pick("freelancer")} className="group text-left rounded-3xl border border-border bg-card p-8 transition hover:shadow-elegant hover:-translate-y-0.5">
            <div className="grid h-12 w-12 place-items-center rounded-xl bg-gradient-accent shadow-glow">
              <Pencil className="h-6 w-6 text-accent-foreground" />
            </div>
            <h2 className="mt-4 font-display text-xl font-semibold">I want to work</h2>
            <p className="mt-2 text-sm text-muted-foreground">Build a professional profile, browse jobs, and win projects in your area of expertise.</p>
            {isFreelancer && <span className="mt-4 inline-block text-xs text-secondary">✓ You already have this role</span>}
          </button>
        </div>

        <Card className="mt-8 bg-surface">
          <CardContent className="p-6 text-sm text-muted-foreground">
            <strong className="text-foreground">Freelancers:</strong> After picking this role, you'll be asked to complete your profile before applying to jobs. Skill assessments and portfolio uploads are coming soon.
          </CardContent>
        </Card>

        <div className="mt-6 text-center">
          <Button asChild variant="ghost"><a href="/dashboard">Skip for now</a></Button>
        </div>
      </section>
    </SiteShell>
  );
}
