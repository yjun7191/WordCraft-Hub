import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { SiteShell } from "@/components/site-shell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { useSession } from "@/lib/auth-hooks";
import { useQuery } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { z } from "zod";

export const Route = createFileRoute("/_authenticated/profile")({
  head: () => ({ meta: [{ title: "Your profile — WordCraft Hub" }, { name: "robots", content: "noindex" }] }),
  component: ProfilePage,
});

const schema = z.object({
  full_name: z.string().trim().min(2).max(100),
  headline: z.string().trim().max(160).optional().or(z.literal("")),
  bio: z.string().trim().max(2000).optional().or(z.literal("")),
  country: z.string().trim().max(60).optional().or(z.literal("")),
  hourly_rate: z.number().min(0).max(10000).optional(),
  skills: z.string().max(500).optional(),
  languages: z.string().max(300).optional(),
});

function ProfilePage() {
  const { user } = useSession();
  const navigate = useNavigate();
  const [saving, setSaving] = useState(false);

  const profileQ = useQuery({
    queryKey: ["profile-edit", user?.id],
    queryFn: async () => {
      if (!user) return null;
      const { data } = await supabase.from("profiles").select("*").eq("id", user.id).maybeSingle();
      return data;
    },
    enabled: !!user,
  });

  const [form, setForm] = useState({
    full_name: "", headline: "", bio: "", country: "", hourly_rate: "",
    skills: "", languages: "",
  });

  useEffect(() => {
    if (profileQ.data) {
      setForm({
        full_name: profileQ.data.full_name ?? "",
        headline: profileQ.data.headline ?? "",
        bio: profileQ.data.bio ?? "",
        country: profileQ.data.country ?? "",
        hourly_rate: profileQ.data.hourly_rate?.toString() ?? "",
        skills: (profileQ.data.skills ?? []).join(", "),
        languages: (profileQ.data.languages ?? []).join(", "),
      });
    }
  }, [profileQ.data]);

  async function save(e: React.FormEvent) {
    e.preventDefault();
    const parsed = schema.safeParse({
      full_name: form.full_name,
      headline: form.headline,
      bio: form.bio,
      country: form.country,
      hourly_rate: form.hourly_rate ? Number(form.hourly_rate) : undefined,
      skills: form.skills,
      languages: form.languages,
    });
    if (!parsed.success) return toast.error(parsed.error.issues[0].message);
    if (!user) return;
    setSaving(true);
    const { error } = await supabase.from("profiles").update({
      full_name: parsed.data.full_name,
      headline: parsed.data.headline || null,
      bio: parsed.data.bio || null,
      country: parsed.data.country || null,
      hourly_rate: parsed.data.hourly_rate ?? null,
      skills: form.skills ? form.skills.split(",").map((s) => s.trim()).filter(Boolean) : [],
      languages: form.languages ? form.languages.split(",").map((s) => s.trim()).filter(Boolean) : [],
      is_onboarded: true,
    }).eq("id", user.id);
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success("Profile saved");
    navigate({ to: "/dashboard" });
  }

  return (
    <SiteShell>
      <section className="mx-auto max-w-2xl px-4 py-10 sm:px-6 lg:px-8">
        <h1 className="font-display text-3xl font-bold">Your profile</h1>
        <p className="mt-1 text-muted-foreground">This information appears on your public profile and job applications.</p>

        <Card className="mt-8">
          <CardHeader><CardTitle className="font-display">Profile details</CardTitle></CardHeader>
          <CardContent>
            <form onSubmit={save} className="space-y-4">
              <div>
                <Label htmlFor="name">Full name</Label>
                <Input id="name" value={form.full_name} onChange={(e) => setForm({ ...form, full_name: e.target.value })} maxLength={100} required />
              </div>
              <div>
                <Label htmlFor="headline">Headline</Label>
                <Input id="headline" placeholder="e.g. Certified medical translator, EN↔ES" value={form.headline} onChange={(e) => setForm({ ...form, headline: e.target.value })} maxLength={160} />
              </div>
              <div>
                <Label htmlFor="bio">Bio</Label>
                <Textarea id="bio" rows={5} placeholder="Tell clients about your experience and specialties…" value={form.bio} onChange={(e) => setForm({ ...form, bio: e.target.value })} maxLength={2000} />
              </div>
              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <Label htmlFor="country">Country</Label>
                  <Input id="country" value={form.country} onChange={(e) => setForm({ ...form, country: e.target.value })} maxLength={60} />
                </div>
                <div>
                  <Label htmlFor="rate">Hourly rate (USD)</Label>
                  <Input id="rate" type="number" min="0" step="0.01" value={form.hourly_rate} onChange={(e) => setForm({ ...form, hourly_rate: e.target.value })} />
                </div>
              </div>
              <div>
                <Label htmlFor="skills">Skills (comma separated)</Label>
                <Input id="skills" placeholder="Transcription, Medical, EN↔ES, Trados" value={form.skills} onChange={(e) => setForm({ ...form, skills: e.target.value })} maxLength={500} />
              </div>
              <div>
                <Label htmlFor="langs">Languages (comma separated)</Label>
                <Input id="langs" placeholder="English (native), Spanish (fluent)" value={form.languages} onChange={(e) => setForm({ ...form, languages: e.target.value })} maxLength={300} />
              </div>
              <Button type="submit" disabled={saving} className="bg-gradient-brand hover:opacity-90 w-full">
                {saving ? "Saving…" : "Save profile"}
              </Button>
            </form>
          </CardContent>
        </Card>
      </section>
    </SiteShell>
  );
}
