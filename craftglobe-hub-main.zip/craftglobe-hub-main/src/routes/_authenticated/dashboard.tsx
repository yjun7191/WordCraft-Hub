import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteShell } from "@/components/site-shell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { useQuery } from "@tanstack/react-query";
import { useSession, useUserRoles } from "@/lib/auth-hooks";
import { Briefcase, FileText, PlusCircle, Send, Sparkles } from "lucide-react";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({ meta: [{ title: "Dashboard — WordCraft Hub" }, { name: "robots", content: "noindex" }] }),
  component: Dashboard,
});

function Dashboard() {
  const { user } = useSession();
  const { isFreelancer, isClient, loading: rolesLoading } = useUserRoles(user?.id);

  const profileQ = useQuery({
    queryKey: ["me-profile", user?.id],
    queryFn: async () => {
      if (!user) return null;
      const { data } = await supabase.from("profiles").select("*").eq("id", user.id).maybeSingle();
      return data;
    },
    enabled: !!user,
  });

  const myJobsQ = useQuery({
    queryKey: ["my-jobs", user?.id],
    queryFn: async () => {
      if (!user) return [];
      const { data } = await supabase.from("jobs").select("id, title, status, applications_count, created_at").eq("client_id", user.id).order("created_at", { ascending: false }).limit(10);
      return data ?? [];
    },
    enabled: !!user && isClient,
  });

  const myApplicationsQ = useQuery({
    queryKey: ["my-applications", user?.id],
    queryFn: async () => {
      if (!user) return [];
      const { data } = await supabase.from("applications").select("id, status, created_at, jobs(id, title)").eq("freelancer_id", user.id).order("created_at", { ascending: false }).limit(10);
      return data ?? [];
    },
    enabled: !!user && isFreelancer,
  });

  const profile = profileQ.data;
  const greetName = profile?.full_name || user?.email?.split("@")[0] || "there";

  return (
    <SiteShell>
      <section className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <h1 className="font-display text-3xl font-bold">Welcome back, {greetName} 👋</h1>
            <p className="mt-1 text-muted-foreground">Here's what's happening on your account.</p>
          </div>
          <div className="flex flex-wrap gap-2">
            {isClient && <Button asChild className="bg-gradient-brand hover:opacity-90"><Link to="/post-job"><PlusCircle className="mr-2 h-4 w-4" />Post a job</Link></Button>}
            {!isFreelancer && <Button asChild variant="outline"><Link to="/onboarding"><Sparkles className="mr-2 h-4 w-4" />Become a freelancer</Link></Button>}
            <Button asChild variant="ghost"><Link to="/profile">Edit profile</Link></Button>
          </div>
        </div>

        {!rolesLoading && !profile?.is_onboarded && (
          <Card className="mt-6 border-accent/40 bg-accent/5">
            <CardContent className="flex flex-wrap items-center justify-between gap-4 p-6">
              <div>
                <div className="font-display font-semibold">Complete your profile</div>
                <p className="text-sm text-muted-foreground">Add a headline, bio, and skills so clients can find you.</p>
              </div>
              <Button asChild><Link to="/profile">Complete profile</Link></Button>
            </CardContent>
          </Card>
        )}

        <div className="mt-8 grid gap-6 lg:grid-cols-3">
          <StatCard icon={Briefcase} label="Jobs posted" value={String(myJobsQ.data?.length ?? 0)} />
          <StatCard icon={Send} label="Applications sent" value={String(myApplicationsQ.data?.length ?? 0)} />
          <StatCard icon={FileText} label="Profile status" value={profile?.is_onboarded ? "Complete" : "In progress"} />
        </div>

        <div className="mt-8 grid gap-6 lg:grid-cols-2">
          {isClient && (
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="font-display">Your recent jobs</CardTitle>
                <Button asChild variant="ghost" size="sm"><Link to="/post-job">Post another</Link></Button>
              </CardHeader>
              <CardContent className="space-y-2">
                {myJobsQ.data?.length === 0 && <p className="text-sm text-muted-foreground">You haven't posted any jobs yet.</p>}
                {myJobsQ.data?.map((j) => (
                  <Link key={j.id} to="/jobs/$id" params={{ id: j.id }} className="flex items-center justify-between rounded-lg border border-border p-3 hover:bg-muted/50">
                    <div className="min-w-0">
                      <div className="truncate font-medium">{j.title}</div>
                      <div className="text-xs text-muted-foreground">{j.applications_count} applicants · {new Date(j.created_at).toLocaleDateString()}</div>
                    </div>
                    <Badge variant="outline" className="capitalize">{j.status}</Badge>
                  </Link>
                ))}
              </CardContent>
            </Card>
          )}

          {isFreelancer && (
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="font-display">Your applications</CardTitle>
                <Button asChild variant="ghost" size="sm"><Link to="/jobs">Find more work</Link></Button>
              </CardHeader>
              <CardContent className="space-y-2">
                {myApplicationsQ.data?.length === 0 && <p className="text-sm text-muted-foreground">You haven't applied to any jobs yet.</p>}
                {myApplicationsQ.data?.map((a) => (
                  <Link key={a.id} to="/jobs/$id" params={{ id: (a.jobs as { id: string }).id }} className="flex items-center justify-between rounded-lg border border-border p-3 hover:bg-muted/50">
                    <div className="min-w-0">
                      <div className="truncate font-medium">{(a.jobs as { title: string }).title}</div>
                      <div className="text-xs text-muted-foreground">Applied {new Date(a.created_at).toLocaleDateString()}</div>
                    </div>
                    <Badge variant="outline" className="capitalize">{a.status}</Badge>
                  </Link>
                ))}
              </CardContent>
            </Card>
          )}

          {!isFreelancer && !isClient && (
            <Card className="lg:col-span-2">
              <CardContent className="p-8 text-center">
                <p className="text-muted-foreground">Pick a role to get started.</p>
                <div className="mt-4 flex justify-center gap-2">
                  <Button asChild><Link to="/onboarding">Become a freelancer</Link></Button>
                  <Button asChild variant="outline"><Link to="/post-job">Post a job</Link></Button>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </section>
    </SiteShell>
  );
}

function StatCard({ icon: Icon, label, value }: { icon: React.ComponentType<{ className?: string }>; label: string; value: string }) {
  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-center gap-3">
          <div className="grid h-10 w-10 place-items-center rounded-lg bg-gradient-brand"><Icon className="h-5 w-5 text-primary-foreground" /></div>
          <div>
            <div className="text-xs text-muted-foreground">{label}</div>
            <div className="font-display text-2xl font-bold">{value}</div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
