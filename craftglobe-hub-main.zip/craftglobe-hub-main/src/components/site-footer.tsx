import { Link } from "@tanstack/react-router";
import { Sparkles } from "lucide-react";

export function SiteFooter() {
  return (
    <footer className="border-t border-border/60 bg-surface">
      <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="grid gap-10 md:grid-cols-2 lg:grid-cols-5">
          <div className="lg:col-span-2">
            <Link to="/" className="flex items-center gap-2 font-display text-lg font-bold">
              <span className="grid h-8 w-8 place-items-center rounded-lg bg-gradient-brand">
                <Sparkles className="h-4 w-4 text-primary-foreground" />
              </span>
              WordCraft <span className="text-gradient">Hub</span>
            </Link>
            <p className="mt-4 max-w-sm text-sm text-muted-foreground">
              Connecting words, creating opportunities. The global marketplace for transcription, translation, subtitles, editing, and content writing.
            </p>
          </div>

          <FooterCol title="Marketplace" links={[
            { to: "/jobs", label: "Find work" },
            { to: "/categories", label: "Browse categories" },
            { to: "/how-it-works", label: "How it works" },
          ]} />
          <FooterCol title="For clients" links={[
            { to: "/auth", label: "Post a job" },
            { to: "/categories", label: "Hire talent" },
          ]} />
          <FooterCol title="Company" links={[
            { to: "/", label: "About" },
            { to: "/", label: "Contact" },
            { to: "/", label: "Blog" },
          ]} />
        </div>

        <div className="mt-12 flex flex-col-reverse gap-4 border-t border-border/60 pt-6 text-xs text-muted-foreground md:flex-row md:items-center md:justify-between">
          <p>© {new Date().getFullYear()} WordCraft Hub. All rights reserved.</p>
          <p>"Connecting Words, Creating Opportunities."</p>
        </div>
      </div>
    </footer>
  );
}

function FooterCol({ title, links }: { title: string; links: { to: string; label: string }[] }) {
  return (
    <div>
      <h3 className="font-display text-sm font-semibold">{title}</h3>
      <ul className="mt-4 space-y-2 text-sm">
        {links.map((l) => (
          <li key={l.label}>
            <Link to={l.to} className="text-muted-foreground hover:text-foreground">{l.label}</Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
