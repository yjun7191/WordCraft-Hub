
-- 1. profiles: restrict SELECT to authenticated only
DROP POLICY IF EXISTS "Profiles are viewable by everyone" ON public.profiles;
CREATE POLICY "Profiles are viewable by authenticated users"
  ON public.profiles FOR SELECT
  TO authenticated
  USING (true);
REVOKE SELECT ON public.profiles FROM anon;

-- 2. applications: rewrite subquery as EXISTS
DROP POLICY IF EXISTS "Freelancers see own applications" ON public.applications;
CREATE POLICY "Applicants and job owners see applications"
  ON public.applications FOR SELECT
  TO authenticated
  USING (
    auth.uid() = freelancer_id
    OR EXISTS (
      SELECT 1 FROM public.jobs j
      WHERE j.id = applications.job_id
        AND j.client_id = auth.uid()
    )
  );

-- 3. Lock down SECURITY DEFINER functions
REVOKE ALL ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.update_updated_at_column() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.update_job_applications_count() FROM PUBLIC, anon, authenticated;

-- has_role is used inside RLS policies; keep it callable by authenticated only
REVOKE ALL ON FUNCTION public.has_role(uuid, public.app_role) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) TO authenticated;

-- add_role_to_current_user is an RPC invoked during onboarding by signed-in users
REVOKE ALL ON FUNCTION public.add_role_to_current_user(public.app_role) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.add_role_to_current_user(public.app_role) TO authenticated;
