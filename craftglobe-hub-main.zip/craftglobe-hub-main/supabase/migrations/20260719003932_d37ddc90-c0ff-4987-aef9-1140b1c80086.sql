
ALTER TABLE public.jobs ALTER COLUMN client_id DROP NOT NULL;

INSERT INTO public.jobs (client_id, category_id, title, description, experience_level, is_hourly, budget_min, budget_max, status, skills, languages)
VALUES
  (NULL, 'c8443749-f1d5-4b37-9b0b-fb5d0f697d19', 'EN→ES Marketing Translation (Ongoing)', 'Translate weekly marketing copy from English to Spanish. ~5 hours/week, ongoing. Native Spanish speakers preferred.', 'intermediate', true, 9, 9, 'open', ARRAY['Translation','Localization','Marketing copy'], ARRAY['English','Spanish']),
  (NULL, 'c8443749-f1d5-4b37-9b0b-fb5d0f697d19', 'French→English Document Translation', 'Translate legal/business documents from French to English. Accuracy and clean formatting required.', 'intermediate', true, 9, 9, 'open', ARRAY['Translation','Proofreading'], ARRAY['French','English']),
  (NULL, '5a8e7e65-8923-48c2-8db6-273554557fdf', 'Podcast Transcription (Weekly, 60 min)', 'Transcribe a weekly 60-minute English podcast. Clean verbatim, speaker labels, timestamps every 30s.', 'entry', true, 9, 9, 'open', ARRAY['Transcription','Clean verbatim','Timestamps'], ARRAY['English']),
  (NULL, '5a8e7e65-8923-48c2-8db6-273554557fdf', 'Interview Transcription — Research Project', 'Transcribe ~20 hours of recorded interviews. Verbatim with speaker IDs. NDA required.', 'entry', true, 9, 9, 'open', ARRAY['Transcription','Verbatim'], ARRAY['English']);
